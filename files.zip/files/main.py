import os

try:  # attempt to import libraries
    from flask import *
    import csv
    import webbrowser
except ImportError:  # install libraries if they are not present
    raise RuntimeWarning("Libraries not imported! Reinstalling...")
    os.system("pip install flask")
    os.system("pip install csv")
    os.system("pip install webbrowser")
    from flask import *
    import csv
    import webbrowser

app = Flask(__name__)
items = []
x = 0


# function to load items from file
def load_items():
    file = open("items.csv", "r")
    reader = csv.reader(file)
    items = []
    for i in reader:
        items.append(i)
    items = items[0]
    return items


# function to save items to the file
def save():
    file = open("items.csv", "w")
    writer = csv.writer(file)
    writer.writerow(items)
    file.close()


@app.route("/")
def index():
    global items
    items = load_items()
    resp = make_response(render_template("index.html", items=items))
    return resp


@app.route("/clear.html")
def clear():
    global items
    items = []
    save()
    return redirect("/")


@app.route("/clearlast.html")
def clearlast():
    global items
    items = items[:len(items) - 1]
    save()
    return redirect("/")


@app.route('/', methods=['POST'])
def form():
    global items
    global x
    item = request.form["text"]
    print(item)
    if item == "":
        print("Empty! Not adding to list")
    else:
        items.append(item)
    save()
    return redirect("/")


if __name__ == "__main__":
    webbrowser.open("localhost")
    app.run(port=80)
